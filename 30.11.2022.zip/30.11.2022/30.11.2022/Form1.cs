﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _30._11._2022
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] lines = System.IO.File.ReadAllLines(@"C:\Users\uczeń\source\repos\30.11.2022\hasla\tekst.txt");
            string[] lines1 = System.IO.File.ReadAllLines(@"C:\Users\uczeń\source\repos\30.11.2022\hasla\haslo.txt");
            foreach (string line in lines)
            {
                string email = textBox1.Text;
                string password = textBox2.Text;
                if (email == line)
                {
                    foreach (string line1 in lines1)
                    {
                        if (password == line1)
                        {
                            textBox3.Text = "Zalogowano";
                        }
                        else if (email != line)
                        {
                            textBox3.Text = "Coś poszło nie tak";

                        }



                    }

                }




            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string path = @"C:\Users\uczeń\source\repos\30.11.2022\hasla\tekst.txt";
            string path1 = @"C:\Users\uczeń\source\repos\30.11.2022\hasla\haslo.txt";
            if (File.Exists(path))
            {
                string dot = "@";
                string newContent = textBox1.Text;
                if (textBox1.Text.Contains(dot))
                {
                    File.WriteAllText(path, newContent);
                }

            }

            if (File.Exists(path1))
            {
                string dot = "@";
                string newContent = textBox2.Text;
                if (textBox1.Text.Contains(dot))
                {
                    File.WriteAllText(path, newContent);
                }

            }
        }
    }
}